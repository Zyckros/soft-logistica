package com.example.softlogistica.model.invoice

data class Invoice(
    val id: Int,
    val name: String
)