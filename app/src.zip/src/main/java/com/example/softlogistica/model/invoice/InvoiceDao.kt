package com.example.softlogistica.model.invoice

interface InvoiceDao