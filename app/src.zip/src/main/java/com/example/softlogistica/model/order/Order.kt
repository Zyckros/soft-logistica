package com.example.softlogistica.model.order

class Order