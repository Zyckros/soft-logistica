package com.example.softlogistica.model.order

interface OrderDao