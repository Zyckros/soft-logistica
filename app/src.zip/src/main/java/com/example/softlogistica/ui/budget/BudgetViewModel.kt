package com.example.softlogistica.ui.budget

import androidx.lifecycle.ViewModel

class BudgetViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}