package com.example.softlogistica.ui.budget.budget_pending

import androidx.lifecycle.ViewModel

class BudgetPendingViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}