package com.example.softlogistica.ui.chat

class ChatViewModelFactory {
}