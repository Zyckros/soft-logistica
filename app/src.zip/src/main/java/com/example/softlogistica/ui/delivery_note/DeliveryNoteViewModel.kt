package com.example.softlogistica.ui.delivery_note

import androidx.lifecycle.ViewModel

class DeliveryNoteViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}