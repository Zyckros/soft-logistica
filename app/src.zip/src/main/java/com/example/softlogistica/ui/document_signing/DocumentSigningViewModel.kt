package com.example.softlogistica.ui.document_signing

import androidx.lifecycle.ViewModel

class DocumentSigningViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}