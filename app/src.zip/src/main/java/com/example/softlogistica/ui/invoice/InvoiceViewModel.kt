package com.example.softlogistica.ui.invoice

import androidx.lifecycle.ViewModel

class InvoiceViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}