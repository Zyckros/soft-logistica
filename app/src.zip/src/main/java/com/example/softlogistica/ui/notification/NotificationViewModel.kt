package com.example.softlogistica.ui.notification

class NotificationViewModel {
}