package com.example.softlogistica.ui.notification

class NotificationViewModelFactory {
}