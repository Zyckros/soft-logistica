package com.example.softlogistica.ui.order

import androidx.lifecycle.ViewModel

class OrderViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}