package com.example.softlogistica.ui.services

class ServiceRepository {
}