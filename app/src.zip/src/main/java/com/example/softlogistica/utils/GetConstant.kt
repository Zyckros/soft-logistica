package com.example.softlogistica.utils

class GetConstant {
    companion object{
        const val URI = "uri"
        const val PRODUCT = "product"
        const val TECHNICAL = "technical"
        const val DRIVING  = "driving"
        const val HOMOLOGATION = "homologation"
        const val iNVOICE = "invoice"
        const val TRANSPORTATION = "transportation"
        const val NAME_IMAGE = "nameImage"
    }
}