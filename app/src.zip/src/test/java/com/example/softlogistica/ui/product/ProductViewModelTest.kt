package com.example.softlogistica.ui.product

import org.junit.Test

class ProductViewModelTest{

    @Test
    fun refreshproducts_productviewmodel(){

    }
}